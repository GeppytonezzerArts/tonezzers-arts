# Tonezzer Racers — Fact sheet and press kit (version 3.5)

**Tonezzer’s Arts** presents **Tonezzer Racers**, off-road racing in HD voxel art. Free, in your browser.

| | |
|---|---|
| **Title** | Tonezzer Racers |
| **Version** | 3.5 “Saliscendi” (Ups and downs) — 12 reworked circuits (November 2026); since 3.3: Demolition Derby, Trento–Bondone, Stage Rally, Elimination, online leaderboards, the Tonezzer Cup ceremony |
| **Studio** | Tonezzer’s Arts (owner: Giacomo Tonezzer) |
| **Genre** | Arcade off-road racing · hill-climb time attack · rally · derby |
| **Players** | 1–2 (split screen on the same computer) · online leaderboards |
| **Platform** | Web browser (WebGL): PC, Mac, Linux, recent tablets and phones |
| **Price** | Free · no ads, no sign-up, no purchases |
| **Languages** | English, Italian |
| **Controls** | Keyboard, gamepad, touch |
| **Website / play** | https://geppytonezzerarts.github.io/tonezzers-arts/ |
| **Direct link to the game** | https://geppytonezzerarts.github.io/tonezzers-arts/games/tonezzer-racers/?lang=en |
| **Trailer** | `video/tonezzer-racers-trailer-en.mp4` (1080p, 79 s, version 3) · `video/tonezzer-racers-trailer-vertical.mp4` (1080×1920, 15 s) |
| **Contact** | Giacomo Tonezzer (Tonezzer’s Arts) |

## Short description (≈ 300 characters)

Mud, jumps and nitro in HD voxel art, by day or by night. Tonezzer Racers is the off-road racer from Tonezzer’s Arts: 7
vehicles, the Tonezzer Garage, 12 circuits full of ups and downs, 11 hill climbs, Stage Rally, Elimination, Demolition Derby
and online leaderboards. Free in your browser.

## Long description

Seven vehicles, one mud track and zero mercy. **Tonezzer Racers** is the spiritual heir to the off-road arcade racers of
yesteryear, rebuilt voxel by voxel in high definition. Play instantly, in your browser, for free: nothing to install, no
sign-up.

**Version 3.5 — “Saliscendi” (Ups and downs)** gives the twelve Grand Prix circuits a new character: more climbs and dives,
crests you really fly off, and five tracks with a brand-new layout. Every track has its big moment:

* **Wolf Wood**: the new uphill **Wolf Hairpins** and the **Wolf Leap**, a downhill crest that flies.
* **Lakeside Rallycross**: **Le Forcelle**, three gravel hairpins in the woods, and the **Ski Jump** that flies you 60–70 m.
* **Fire Canyon**: the **Lava Circle**, downhill hairpins with a banked wall.
* **Tonezzer Ring**: the **Neon Tower**, three hairpins up to 15 m, then a dive.
* **Three Arches**: a roller coaster, three 22 m arches and three dives · **Death Valley**: a 33 m dive down to Badwater.
* And the Dune of Mesa Grande, the bowl-like banked bends of Tonezzer Stadium, the flooded Pozza of the Black Swamp, the
  Return Hairpins of Devil’s Gorge, La Montagna of the Midnight Rodeo and the Black Run of Snow Pass.

Version 3.5 wraps up the first season of updates, which also brought:

* **Stage Rally** (3.4): the hill climbs back to back against five rivals, the total time counts. Three rallies — the Canyon
  Rally, the Alpine Rally and the Tonezzer Grand Rally, ending on the legendary Trento–Bondone. Damage carries over from
  stage to stage: at the **service park** you repair with Tonezzer Credits, take a quick fix for a few penalty seconds, or
  drive on as you are.
* **Elimination** (3.4): 4 to 6 cars on any circuit; at the end of every lap the last car is out, until only one is left.
  The car that goes out blinks, pulls over and vanishes; the board warns you with a big “YOU’RE LAST!”. Two players too.
* **Online leaderboards** (3.4): hill-climb times, best laps, the daily challenge and the rallies against every player’s.
  Pick a leaderboard name; the game only sends an anonymous id, the name and the times.
* **The Tonezzer Cup** (3.4.1): the Grand Prix gets a real ending, with an **award ceremony** on the podium, the Cup rising
  over the winner, fanfare and fireworks, then the final standings. Between races you can leave the Garage and resume the
  championship whenever you like.
* **Demolition Derby** (3.3): 6 to 8 cars in three arenas, the last one standing wins; real damage by zones, T-bones, sudden
  death.
* **The legendary Trento–Bondone** (3.3): every one of the real road’s forty-plus hairpins, at 1:2 scale, with the real
  gradients.
* **Smoother** (3.3.1–3.4): smoother hill climbs, a graphics-card check at start-up with tips, performance stats on **F3**,
  smarter auto quality and a light audio option.

And everything from the earlier versions: a **real night** with headlights and floodlights, **weather** that changes even
mid-race (rain with thunder and lightning, snow, fog), **living terrain** with ruts that grow lap after lap, the **daily
challenge**, **seven vehicles** (up to the legendary Tonezzer Special), the 3D **Tonezzer Garage** with upgrades, paints,
decals and horns (yes, a rubber duck), **55 Tonezzer Trophies**, **Photo mode**, the **Driving School** and head-to-head
**2-player** split screen.

Soundtrack: the song “Toh-NAY-tser Racers” by Giacomo Tonezzer.

## Feature list

* 12 circuits reworked in 3.5: hairpins stacked one above the other, dives, crests you fly off · a 12-race Grand Prix with the
  Tonezzer Cup ceremony
* 11 hill climbs, including the legendary Trento–Bondone · record ghost · medals up to platinum · over 60 challenges
* Stage Rally: 3 rallies, the service park, damage carried between stages
* Elimination: 4 to 6 cars, the last one out every lap
* Demolition Derby: 3 arenas, 6 to 8 cars, real damage
* Online leaderboards (hill climbs, best laps, daily challenge, rallies) with a leaderboard name, no account
* A real night with headlights and dynamic lights · dynamic weather (rain, snow, fog) · living terrain
* Daily challenge and your personal records
* 7 vehicles with their own physics and engines, upgrades and custom bodywork
* 55 trophies · Photo mode (free drone camera, styles, light, depth of field, PNG export)
* 2-player split screen (shared keyboard or two gamepads) · driving school for beginners
* HD voxel art generated on the fly: no heavy downloads · English / Italiano

## Controls

| | Player 1 | Player 2 | Gamepad |
|---|---|---|---|
| Accelerate | ↑ (or W when alone) | W | A / RT |
| Brake / reverse | ↓ (or S) | S | X / LT |
| Steer | ← → (or A D) | A D | stick |
| Nitro | Space | Q | B / RB |
| Reset truck | R | E | Y |
| Horn | H | G | — |
| Camera / zoom | C / V | | Back / LB |
| Photo mode | F | | from the pause menu |
| Pause · audio · performance | P · M · F3 | | Start |

Touch: left pad to steer, pedals on the right, on-screen buttons for nitro, reset and pause (phone in landscape).

## Requirements

* A modern browser with WebGL (an up-to-date Chrome, Edge, Firefox or Safari).
* A dedicated graphics card is recommended. On laptops with two graphics chips, choose “High performance” for your browser;
  the game checks the graphics card at start-up and gives the right tips. **F3** shows the performance stats.
* Best on a computer with keyboard or gamepad; also runs on recent tablets and phones (automatic graphics quality).
* An internet connection at startup (and for the online leaderboards). Nothing to install: records and progress are saved in
  your browser.

## Credits

* **Giacomo Tonezzer** — concept, direction, art direction, production, test driving (and the record on every track).
* **Development and programming: Claude (Anthropic)**, under the direction of Giacomo Tonezzer.
* **Soundtrack:** “Toh-NAY-tser Racers”, a song by Giacomo Tonezzer, made with **Suno**.
* three.js 3D engine (MIT licence) · Bungee and Barlow Condensed typefaces (SIL Open Font License) · Trento–Bondone road data
  © OpenStreetMap contributors.

## What’s in the kit

* `screenshots/` — 1920×1080 from the actual game: the 16 of version 3 (no interface `*_clean.jpg` and with interface
  `*_hud.jpg`) and 14 new ones for 3.5 (`17-` to `30-`: the reworked circuits, Stage Rally and the service park,
  Elimination, the Rankings page, the Tonezzer Cup, Demolition Derby, Trento–Bondone)
* `keyart/` — covers: itch.io 630×500 and 315×250, capsule 920×430, social 1200×630 (IT and EN), key art 1920×1080 and
  3840×2160
* `logo/` — TONEZZER RACERS logo on transparent, for light and dark backgrounds; the Tonezzer’s Arts crest and wordmark
* `video/` — 1080p trailer of version 3 (79 s; `tonezzer-racers-trailer-en.mp4` with English cards,
  `tonezzer-racers-trailer.mp4` Italian cards with English subtitles), 15 s vertical cut, 7 s muted loop (WebM / MP4 / GIF)
* `factsheet_it.md`, `factsheet_en.md`, `itchio.md` (ready-to-paste itch.io page), `social.md` (suggested posts)

All images are captured from the actual game, unretouched (the leaderboard names in the images are made up). Free to use in
articles, videos and reviews of the game.
