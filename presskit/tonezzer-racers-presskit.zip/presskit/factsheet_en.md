# Tonezzer Racers — Fact sheet and press kit (version 3)

**Tonezzer’s Arts** presents **Tonezzer Racers**, off-road racing in HD voxel art. Free, in your browser.

| | |
|---|---|
| **Title** | Tonezzer Racers |
| **Version** | 3 — a real night, changing weather, living terrain, daily challenge (October 2026) |
| **Studio** | Tonezzer’s Arts (owner: Giacomo Tonezzer) |
| **Genre** | Arcade off-road racing · hill-climb time attack |
| **Players** | 1–2 (split screen on the same computer) |
| **Platform** | Web browser (WebGL): PC, Mac, Linux, recent tablets and phones |
| **Price** | Free · no ads, no sign-up, no purchases |
| **Languages** | English, Italian |
| **Controls** | Keyboard, gamepad, touch |
| **Website / play** | https://geppytonezzerarts.github.io/tonezzers-arts/ |
| **Direct link to the game** | https://geppytonezzerarts.github.io/tonezzers-arts/games/tonezzer-racers/?lang=en |
| **Trailer** | `video/tonezzer-racers-trailer-en.mp4` (1080p, 79 s) · `video/tonezzer-racers-trailer-vertical.mp4` (1080×1920, 15 s) |
| **Contact** | Giacomo Tonezzer (Tonezzer’s Arts) |

## Short description (≈ 300 characters)

Mud, jumps and nitro in HD voxel art, by day or by night, in rain, snow or fog. Tonezzer Racers is the off-road racer from
Tonezzer’s Arts: 7 vehicles, the Tonezzer Garage, 12 circuits, 10 hill climbs, ruts that grow lap after lap and a daily
challenge. Free in your browser.

## Long description

Four trucks, one mud track and zero mercy. **Tonezzer Racers** is the spiritual heir to the off-road arcade racers of
yesteryear, rebuilt voxel by voxel in high definition. Play instantly, in your browser, for free: nothing to install, no
sign-up.

**Version 3** brings the night, the weather and a track that wears under your wheels:

* **A real night**: headlights that light up the road and glint in the puddles, floodlight towers casting pools of light on
  the dirt, street lamps, reflective markers along the edges, stars and moon. At **sunset** the light fades during the race and
  the headlights come on.
* **Changing weather**: clear, **rain** (a wet, slippery track, mud, thunder and lightning), **snow** (the track turns white) or
  **fog** (follow the reflectors), and it can change mid-race ("It's starting to rain!"). Pick the time of day and the weather
  for every race and hill climb; in the Grand Prix they change every race.
* **Living terrain**: lap after lap the wheels dig ruts in dirt, mud, sand and snow; the tracks darken, deep ruts fill with
  water and pull your wheels a little. Also available as visual only, or off.
* **Daily challenge**: every day a climb or a circuit, the same vehicle for everyone, a special rule and its own sky; your best
  time counts, +150 credits for the first finish and a streak of days in a row. **Records** keeps your personal bests for the
  challenges, the hill climbs and every circuit's fastest lap.

And everything that came with **version 2 — “Garage Tonezzer”**:

* **Seven vehicles**, each with its own character: the Classic Pick-up, the Vintage Jeep that climbs anything, the Buggy
  Zanzara born to fly, the Rally Saetta, the whoop-eating Desert Trophy Truck, the rock-crushing (and rival-pushing) Monster
  Bestione and the legendary **Tonezzer Special**, to unlock.
* **The 3D Tonezzer Garage**: engine, turbo, transmission, tyres, suspension, chassis, nitro and armour, four tyre compounds,
  paints, finishes, stripes, rims, numbers, decals and horns (yes, the rubber duck too). Your career is saved.
* **12 circuits** from desert to canyon at sunset, from swamp to alpine forest, from snow to floodlit night stadiums — new:
  **Tonezzer Stadium**, with fireworks on the final lap, and **Rallycross del Lago**.
* **10 hill climbs** from valley to summit against the clock and your own ghost, with medals from bronze to platinum and
  challenges with rewards. Four are new and epic: **Cima delle Nuvole** (Cloud Peak) at sunset above a sea of clouds, **La
  Strada della Forra** (Gorge Road) through rock galleries, over bridges and past a ruined castle, **Il Vulcano Tonezzer**
  around a lava crater and **Il Passo del Ghiacciaio** (Glacier Pass) with a crevasse to jump.
* **40 Tonezzer Trophies**, some of them secret; a **Photo mode** with postcard, vintage and black-and-white styles;
  **cosmetic damage** (dents, cracked glass, flying parts — Tonezzer pays the bill).
* The **Tonezzer Driving School** for newcomers, the **Tonezzer’s Arts Grand Prix** against the Baron for the **Tonezzer
  Cup**, and head-to-head **2-player** split screen.
* In **English and Italian**, with keyboard, gamepad or touch.

Soundtrack: the song “Toh-NAY-tser Racers” by Giacomo Tonezzer.

## Feature list

* A real night with headlights and dynamic lights · sunset fading into night during the race
* Dynamic weather: rain with thunder, lightning and puddles, snow that whitens the track, fog · even mid-race
* Living terrain: ruts and puddles that grow lap after lap (Yes / Visual only / No)
* Daily challenge (same vehicle and rule for everyone, day streak) and your personal records
* 7 vehicles with their own physics and engines, upgrades and custom bodywork
* 12 circuits · 12-race Grand Prix · Tonezzer Cup
* 10 hill climbs · record ghost · bronze / silver / gold / platinum medals · 49 challenges
* 40 trophies in five families
* Photo mode (free drone camera, styles, light, depth of field, PNG export)
* 2-player split screen (shared keyboard or two gamepads)
* Driving school for beginners, one-time tips
* HD voxel art generated on the fly: no heavy downloads
* English / Italiano

## Controls

| | Player 1 | Player 2 | Gamepad |
|---|---|---|---|
| Accelerate | ↑ (or W when alone) | W | A / RT |
| Brake / reverse | ↓ (or S) | S | X / LT |
| Steer | ← → (or A D) | A D | stick |
| Nitro | Space | Q | B / RB |
| Reset truck | R | E | Y |
| Horn | H | G | — |
| Camera / zoom | C / V | | Back / LB |
| Photo mode | F | | from the pause menu |
| Pause · audio | P · M | | Start |

Touch: left pad to steer, pedals on the right, on-screen buttons for nitro, reset and pause (phone in landscape).

## Requirements

* A modern browser with WebGL (an up-to-date Chrome, Edge, Firefox or Safari).
* Best on a computer with keyboard or gamepad; also runs on recent tablets and phones (automatic graphics quality).
* An internet connection at startup. Nothing to install: records and progress are saved in your browser.

## Credits

* **Giacomo Tonezzer** — concept, direction, art direction, production, test driving (and the record on every track).
* **Development and programming: Claude (Anthropic)**, under the direction of Giacomo Tonezzer.
* **Soundtrack:** “Toh-NAY-tser Racers”, a song by Giacomo Tonezzer, made with **Suno**.
* three.js 3D engine (MIT licence) · Bungee and Barlow Condensed typefaces (SIL Open Font License).

## What’s in the kit

* `screenshots/` — 16 images at 1920×1080, six new in v3: night, rain, snow, living terrain, fog, the volcano at night (no interface `*_clean.jpg` and with interface `*_hud.jpg`)
* `keyart/` — covers: itch.io 630×500 and 315×250, capsule 920×430, social 1200×630 (IT and EN), key art 1920×1080
* `logo/` — TONEZZER RACERS logo on transparent, for light and dark backgrounds; the Tonezzer’s Arts crest
* `video/` — 1080p trailer of version 3 (79 s; `tonezzer-racers-trailer-en.mp4` with English cards, `tonezzer-racers-trailer.mp4` Italian cards with English subtitles), 15 s vertical cut, 7 s muted loop (WebM / MP4 / GIF)
* `factsheet_it.md`, `factsheet_en.md`, `itchio.md` (ready-to-paste itch.io page), `social.md` (suggested posts)

All images are captured from the actual game, unretouched. Free to use in articles, videos and reviews of the game.
