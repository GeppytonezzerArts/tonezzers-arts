# Suggested social posts / Post suggeriti

Link: https://geppytonezzerarts.github.io/tonezzers-arts/ · Media: `video/tonezzer-racers-trailer-vertical.mp4` (Reels,
Shorts, TikTok), `video/tonezzer-racers-trailer.mp4` (YouTube, X, Facebook), `keyart/social-1200x630-it.jpg` /
`social-1200x630-en.jpg`, `video/tonezzer-racers-loop.gif`, `screenshots/`.

## Italiano

**Lancio (trailer)**
> 🏁 È arrivata la versione 3 di Tonezzer Racers! Notte vera con fari e riflettori, pioggia con tuoni e lampi, neve e nebbia,
> solchi che crescono giro dopo giro e una Sfida del giorno nuova ogni giorno. Fango, salti e nitro in voxel art HD — gratis
> nel browser.
> 👉 geppytonezzerarts.github.io/tonezzers-arts
> #TonezzerRacers #TonezzersArts #voxelart #giochigratis #indiegame

**Reel / Short (verticale, 15 s)**
> Toh-NAY-tser Racers! 🎶 Di notte, sotto la pioggia, nella neve. Gioca gratis, niente da installare 👉 link in bio
> #TonezzerRacers #gaming #voxel #racinggame

**Notte vera**
> Si spengono le luci del giorno, si accendono i fari. Le gare di notte ora sono notte davvero: torri di luci, pozze di luce
> sulla terra e i fari che luccicano nelle pozzanghere. 🌙🏁 #TonezzerRacers

**Meteo**
> «Comincia a piovere!» Pista bagnata, fango, tuoni e lampi. O la neve che imbianca il bosco, o la nebbia in fondo alla valle.
> Scegli tu il cielo, o lascialo al caso. 🌧️❄️🌫️ #TonezzerRacers

**Terreno vivo**
> Giro dopo giro le ruote scavano la pista: solchi, fango sulle gomme e pozzanghere nei solchi profondi. Il terreno ora è vivo.
> 🛞 #TonezzerRacers

**Sfida del giorno**
> Ogni giorno una sfida nuova: stessa salita, stesso mezzo e stessa regola per tutti. Quanti giorni di fila riesci a fare? 📅
> #TonezzerRacers

**Cima delle Nuvole**
> Al tramonto, sopra il mare di nuvole, 400 m di dislivello e il tuo fantasma da battere. La nuova cronoscalata Cima delle Nuvole
> ti aspetta. ⛰️🌅 #TonezzerRacers

**Garage**
> Motore, turbo, gomme chiodate, vernice Oro Tonezzer e il clacson a paperella 🦆. Il Garage Tonezzer è aperto: quale mezzo
> scegli? #TonezzerRacers

**2 giocatori**
> Le amicizie più solide finiscono qui, al primo tornante. 2 giocatori sullo stesso schermo, tastiera condivisa o due gamepad.
> 👥🏁 #TonezzerRacers

**Modalità foto**
> Premi F, scegli “Cartolina” e manda i saluti dal Vulcano Tonezzer. 📸 Condividi i tuoi scatti con #TonezzerRacers

## English

**Launch (trailer)**
> 🏁 Tonezzer Racers version 3 is here! A real night with headlights and floodlights, rain with thunder and lightning, snow and
> fog, ruts that grow lap after lap and a new daily challenge every day. Mud, jumps and nitro in HD voxel art — free in your
> browser.
> 👉 geppytonezzerarts.github.io/tonezzers-arts
> #TonezzerRacers #TonezzersArts #voxelart #freegames #indiegame

**Reel / Short (vertical, 15 s)**
> Toh-NAY-tser Racers! 🎶 By night, in the rain, in the snow. Play free, nothing to install 👉 link in bio
> #TonezzerRacers #gaming #voxel #racinggame

**A real night**
> The daylight goes, the headlights come on. Night races are now truly night: floodlight towers, pools of light on the dirt and
> headlights glinting in the puddles. 🌙🏁 #TonezzerRacers

**Weather**
> "It's starting to rain!" A wet track, mud, thunder and lightning. Or snow turning the forest white, or fog down in the
> valley. Pick your sky, or leave it to chance. 🌧️❄️🌫️ #TonezzerRacers

**Living terrain**
> Lap after lap the wheels dig into the track: ruts, mud on the tyres and puddles in the deep ruts. The ground is alive now. 🛞
> #TonezzerRacers

**Daily challenge**
> A new challenge every day: same climb, same vehicle, same rule for everyone. How many days in a row can you make it? 📅
> #TonezzerRacers

**Cloud Peak**
> Sunset, a sea of clouds below, 400 m of climb and your own ghost to beat. The new Cima delle Nuvole hill climb is waiting.
> ⛰️🌅 #TonezzerRacers

**Garage**
> Engine, turbo, studded tyres, Tonezzer Gold paint and the rubber-duck horn 🦆. The Tonezzer Garage is open: which ride is
> yours? #TonezzerRacers

**2 players**
> The strongest friendships end right here, at the first hairpin. 2 players on one screen, shared keyboard or two gamepads.
> 👥🏁 #TonezzerRacers

**Photo mode**
> Press F, pick “Postcard” and send greetings from Tonezzer’s Volcano. 📸 Share your shots with #TonezzerRacers
