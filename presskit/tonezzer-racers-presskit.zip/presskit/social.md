# Suggested social posts / Post suggeriti

Link: https://geppytonezzerarts.github.io/tonezzers-arts/ · Media: `video/tonezzer-racers-trailer-vertical.mp4` (Reels,
Shorts, TikTok), `video/tonezzer-racers-trailer.mp4` (YouTube, X, Facebook), `keyart/social-1200x630-it.jpg` /
`social-1200x630-en.jpg`, `video/tonezzer-racers-loop.gif`, `screenshots/`.

## Italiano

**Lancio (trailer)**
> 🏁 È arrivata la versione 2 di Tonezzer Racers! 7 mezzi, il Garage Tonezzer, 12 circuiti, 10 cronoscalate, 40 trofei e la
> modalità foto. Fango, salti e nitro in voxel art HD — gratis nel browser.
> 👉 geppytonezzerarts.github.io/tonezzers-arts
> #TonezzerRacers #TonezzersArts #voxelart #giochigratis #indiegame

**Reel / Short (verticale, 15 s)**
> Toh-NAY-tser Racers! 🎶 Più veloci e più in alto. Gioca gratis, niente da installare 👉 link in bio
> #TonezzerRacers #gaming #voxel #racinggame

**Cima delle Nuvole**
> Al tramonto, sopra il mare di nuvole, 400 m di dislivello e il tuo fantasma da battere. La nuova cronoscalata Cima delle Nuvole
> ti aspetta. ⛰️🌅 #TonezzerRacers

**Garage**
> Motore, turbo, gomme chiodate, vernice Oro Tonezzer e il clacson a paperella 🦆. Il Garage Tonezzer è aperto: quale mezzo
> scegli? #TonezzerRacers

**2 giocatori**
> Le amicizie più solide finiscono qui, al primo tornante. 2 giocatori sullo stesso schermo, tastiera condivisa o due gamepad.
> 👥🏁 #TonezzerRacers

**Modalità foto**
> Premi F, scegli “Cartolina” e manda i saluti dal Vulcano Tonezzer. 📸 Condividi i tuoi scatti con #TonezzerRacers

## English

**Launch (trailer)**
> 🏁 Tonezzer Racers version 2 is here! 7 vehicles, the Tonezzer Garage, 12 circuits, 10 hill climbs, 40 trophies and a photo
> mode. Mud, jumps and nitro in HD voxel art — free in your browser.
> 👉 geppytonezzerarts.github.io/tonezzers-arts
> #TonezzerRacers #TonezzersArts #voxelart #freegames #indiegame

**Reel / Short (vertical, 15 s)**
> Toh-NAY-tser Racers! 🎶 Faster and higher. Play free, nothing to install 👉 link in bio
> #TonezzerRacers #gaming #voxel #racinggame

**Cloud Peak**
> Sunset, a sea of clouds below, 400 m of climb and your own ghost to beat. The new Cima delle Nuvole hill climb is waiting.
> ⛰️🌅 #TonezzerRacers

**Garage**
> Engine, turbo, studded tyres, Tonezzer Gold paint and the rubber-duck horn 🦆. The Tonezzer Garage is open: which ride is
> yours? #TonezzerRacers

**2 players**
> The strongest friendships end right here, at the first hairpin. 2 players on one screen, shared keyboard or two gamepads.
> 👥🏁 #TonezzerRacers

**Photo mode**
> Press F, pick “Postcard” and send greetings from Tonezzer’s Volcano. 📸 Share your shots with #TonezzerRacers
