# Tonezzer Racers — Kit stampa / Press kit (v3)

**Tonezzer’s Arts** · Giacomo Tonezzer · https://geppytonezzerarts.github.io/tonezzers-arts/

Italiano: [factsheet_it.md](factsheet_it.md) · English: [factsheet_en.md](factsheet_en.md) · itch.io: [itchio.md](itchio.md) ·
Social: [social.md](social.md)

| Cartella / Folder | Contenuto / Contents |
|---|---|
| `screenshots/` | 16 schermate 1920×1080 dal gioco (6 nuove della v3: notte, pioggia, neve, terreno vivo, nebbia, il Vulcano di notte), senza interfaccia (`_clean`) e con interfaccia (`_hud`) · 16 in-game screenshots (6 new in v3: night, rain, snow, living terrain, fog, the volcano at night), without (`_clean`) and with the HUD (`_hud`) |
| `keyart/` | key art 1920×1080 (IT, EN) e 3840×2160 (EN), copertine itch.io 630×500 e 315×250, capsula 920×430, social 1200×630 (IT, EN) |
| `logo/` | logo TONEZZER RACERS (PNG trasparente, per fondi scuri e chiari), stemma e marchio Tonezzer’s Arts · logo, crest and studio wordmark |
| `video/` | trailer della versione 3 / version 3 trailer, 1080p 30 fps (79 s, H.264 + AAC, -14 LUFS): IT con sottotitoli EN e versione EN (`-en`); taglio verticale 1080×1920 da 15 s; loop muto da 7 s (WebM, MP4, GIF); poster |

Trailer online: https://geppytonezzerarts.github.io/tonezzers-arts/video/tonezzer-racers-trailer.mp4

Uso libero per articoli, video, recensioni e post sul gioco. Free to use in articles, videos, reviews and posts about the game.

Riconoscimenti / Credits: Giacomo Tonezzer (ideazione e regia / concept and direction) · sviluppo / development: Claude
(Anthropic), sotto la direzione di / under the direction of Giacomo Tonezzer · colonna sonora / soundtrack: “Toh-NAY-tser
Racers” di / by Giacomo Tonezzer, realizzata con / made with Suno.
