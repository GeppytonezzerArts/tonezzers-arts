# Tonezzer Racers — Kit stampa / Press kit (v3.5 “Saliscendi”)

**Tonezzer’s Arts** · Giacomo Tonezzer · https://geppytonezzerarts.github.io/tonezzers-arts/

Italiano: [factsheet_it.md](factsheet_it.md) · English: [factsheet_en.md](factsheet_en.md) · itch.io: [itchio.md](itchio.md) ·
Social: [social.md](social.md)

| Cartella / Folder | Contenuto / Contents |
|---|---|
| `screenshots/` | 30 schermate 1920×1080 dal gioco: le 16 della v3 senza interfaccia (`_clean`) e con interfaccia (`_hud`) e 14 nuove della v3.5 (circuiti rinnovati, Rally a tappe e parco assistenza, Eliminazione, Classifiche, Coppa Tonezzer, Demolition Derby, Trento–Bondone) · 30 in-game screenshots: the 16 of v3 without (`_clean`) and with the HUD (`_hud`), and 14 new ones for v3.5 (reworked circuits, Stage Rally and the service park, Elimination, Rankings, the Tonezzer Cup, Demolition Derby, Trento–Bondone) |
| `keyart/` | key art 1920×1080 (IT, EN) e 3840×2160 (EN), copertine itch.io 630×500 e 315×250, capsula 920×430, social 1200×630 (IT, EN) |
| `logo/` | logo TONEZZER RACERS (PNG trasparente, per fondi scuri e chiari), stemma e marchio Tonezzer’s Arts · logo, crest and studio wordmark |
| `video/` | trailer della versione 3 / version 3 trailer, 1080p 30 fps (79 s, H.264 + AAC, -14 LUFS): IT con sottotitoli EN e versione EN (`-en`); taglio verticale 1080×1920 da 15 s; loop muto da 7 s (WebM, MP4, GIF); poster |

Trailer online (lo zip del sito non contiene i video, scaricabili qui / the site's zip leaves the videos out, download them here):
https://geppytonezzerarts.github.io/tonezzers-arts/video/tonezzer-racers-trailer.mp4 ·
https://geppytonezzerarts.github.io/tonezzers-arts/video/tonezzer-racers-trailer-en.mp4 ·
https://geppytonezzerarts.github.io/tonezzers-arts/video/tonezzer-racers-trailer-vertical.mp4 ·
https://geppytonezzerarts.github.io/tonezzers-arts/video/tonezzer-racers-loop.mp4

Uso libero per articoli, video, recensioni e post sul gioco. Free to use in articles, videos, reviews and posts about the game.

Riconoscimenti / Credits: Giacomo Tonezzer (ideazione e regia / concept and direction) · sviluppo / development: Claude
(Anthropic), sotto la direzione di / under the direction of Giacomo Tonezzer · colonna sonora / soundtrack: “Toh-NAY-tser
Racers” di / by Giacomo Tonezzer, realizzata con / made with Suno.
