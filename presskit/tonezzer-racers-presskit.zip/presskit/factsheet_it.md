# Tonezzer Racers — Scheda e kit stampa (versione 3.5)

**Tonezzer’s Arts** presenta **Tonezzer Racers**, corse off-road in voxel art HD. Gratis, nel browser.

| | |
|---|---|
| **Titolo** | Tonezzer Racers |
| **Versione** | 3.5 “Saliscendi” — 12 circuiti rinnovati (novembre 2026); dalla 3.3: Demolition Derby, Trento–Bondone, Rally a tappe, Eliminazione, classifiche online, Coppa Tonezzer con premiazione |
| **Studio** | Tonezzer’s Arts (titolare: Giacomo Tonezzer) |
| **Genere** | Corse arcade off-road · cronoscalate a tempo · rally · derby |
| **Giocatori** | 1–2 (schermo diviso sullo stesso computer) · classifiche online |
| **Piattaforma** | Browser web (WebGL): PC, Mac, Linux, tablet e telefoni recenti |
| **Prezzo** | Gratis · niente pubblicità, niente registrazione, niente acquisti |
| **Lingue** | Italiano, English |
| **Comandi** | Tastiera, gamepad, touch |
| **Sito / gioca** | https://geppytonezzerarts.github.io/tonezzers-arts/ |
| **Gioco diretto** | https://geppytonezzerarts.github.io/tonezzers-arts/games/tonezzer-racers/ |
| **Trailer** | `video/tonezzer-racers-trailer.mp4` (1080p, 79 s, versione 3) · `video/tonezzer-racers-trailer-vertical.mp4` (1080×1920, 15 s) |
| **Contatti** | Giacomo Tonezzer (Tonezzer’s Arts) |

## Descrizione breve (≈ 300 caratteri)

Fango, salti e nitro in voxel art HD, di giorno e di notte. Tonezzer Racers è il gioco di corse off-road di Tonezzer’s Arts:
7 mezzi, il Garage Tonezzer, 12 circuiti tutti saliscendi, 11 cronoscalate, Rally a tappe, Eliminazione, Demolition Derby e
classifiche online. Gratis nel browser.

## Descrizione lunga

Sette mezzi, una pista di fango e zero pietà. **Tonezzer Racers** è l’erede spirituale dei giochi di corse off-road da sala
giochi di una volta, ricostruito voxel per voxel in alta definizione. Si gioca subito, nel browser, gratis: niente da
installare, niente registrazione.

La **versione 3.5 — “Saliscendi”** cambia carattere ai dodici circuiti del Gran Premio: più salite e picchiate, dossi da cui
si vola davvero e cinque piste con un tracciato nuovo. Ogni pista ha il suo momento forte:

* **Bosco del Lupo**: i nuovi **Tornanti del Lupo** in salita e **Il Salto del Lupo**, un dosso che vola in discesa.
* **Rallycross del Lago**: **Le Forcelle**, tre tornanti di ghiaia nel bosco, e il **Trampolino** che fa volare per 60–70 m.
* **Canyon del Fuoco**: **Il Girone di Lava**, tornanti in discesa con un muro sopraelevato.
* **Tonezzer Ring**: la **Torre dei Neon**, tre tornanti fino a 15 m, poi giù in picchiata.
* **Tre Archi**: montagne russe, tre archi alti 22 m e tre picchiate · **Valle della Morte**: un tuffo di 33 m fino a Badwater.
* E ancora la Duna di Mesa Grande, le paraboliche a catino del Tonezzer Stadium, la Pozza della Palude Nera, i Tornanti del
  Ritorno della Gola del Diavolo, La Montagna del Rodeo di Mezzanotte e la Pista Nera del Passo della Neve.

Con la 3.5 si chiude la prima stagione di aggiornamenti, che ha portato anche:

* **Rally a tappe** (3.4): le cronoscalate una dopo l’altra contro cinque rivali, conta la somma dei tempi. Tre rally — Rally
  dei Canyon, Rally delle Alpi e Gran Rally Tonezzer, che finisce sulla leggendaria Trento–Bondone. I danni restano da una
  prova all’altra: al **parco assistenza** si sceglie se riparare con i Crediti Tonezzer, riparare in fretta con qualche
  secondo di penalità o ripartire così.
* **Eliminazione** (3.4): da 4 a 6 auto su qualsiasi circuito; alla fine di ogni giro l’ultimo è fuori, finché ne resta uno.
  Chi è fuori lampeggia, accosta e sparisce; il tabellone avvisa con un grande «SEI ULTIMO!». Anche in due.
* **Classifiche online** (3.4): tempi delle cronoscalate, giri veloci, Sfida del giorno e rally contro quelli di tutti i
  giocatori. Si sceglie un nome in classifica; il gioco invia solo un codice anonimo, il nome e i tempi.
* **La Coppa Tonezzer** (3.4.1): il Gran Premio ha una fine vera, con la **premiazione** sul podio, la Coppa che si alza sul
  vincitore, fanfara e fuochi d’artificio, poi la classifica finale. Tra una gara e l’altra si può uscire dal Garage e
  riprendere il campionato quando si vuole.
* **Demolition Derby** (3.3): da 6 a 8 auto in tre arene, l’ultimo in piedi vince; danni veri per zone, colpi a T, morte
  improvvisa.
* **La leggendaria Trento–Bondone** (3.3): tutti gli oltre quaranta tornanti della strada vera, in scala 1:2, con le
  pendenze vere.
* **Più fluido** (3.3.1–3.4): cronoscalate più fluide, controllo della scheda video all’avvio con consigli, statistiche delle
  prestazioni con **F3**, qualità automatica più furba e un’opzione audio leggera.

E c’è tutto quello delle versioni precedenti: la **notte vera** con fari e riflettori, il **meteo** che cambia anche in gara
(pioggia con tuoni e lampi, neve, nebbia), il **terreno vivo** con i solchi che crescono giro dopo giro, la **Sfida del
giorno**, i **sette mezzi** (fino alla leggendaria Tonezzer Special), il **Garage Tonezzer** in 3D con potenziamenti, vernici,
adesivi e clacson (sì, anche la paperella), **55 Trofei Tonezzer**, la **Modalità foto**, la **Scuola guida** e il duello a
**2 giocatori** a schermo diviso.

Colonna sonora: la canzone “Toh-NAY-tser Racers” di Giacomo Tonezzer.

## Caratteristiche (elenco)

* 12 circuiti rinnovati nella 3.5: tornanti uno sopra l’altro, picchiate, dossi da cui si vola · Gran Premio da 12 gare con la
  premiazione della Coppa Tonezzer
* 11 cronoscalate, tra cui la leggendaria Trento–Bondone · fantasma del record · medaglie fino al platino · oltre 60 sfide
* Rally a tappe: 3 rally, parco assistenza, danni che restano tra le prove
* Eliminazione: da 4 a 6 auto, l’ultimo fuori a ogni giro
* Demolition Derby: 3 arene, da 6 a 8 auto, danni veri
* Classifiche online (cronoscalate, giri veloci, Sfida del giorno, rally) con nome in classifica, senza account
* Notte vera con fari e luci dinamiche · meteo dinamico (pioggia, neve, nebbia) · terreno vivo
* Sfida del giorno e i tuoi record personali
* 7 mezzi con fisica e motore propri, potenziamenti e carrozzeria personalizzabile
* 55 trofei · Modalità foto (drone libero, stili, luce, sfocatura, PNG)
* 2 giocatori a schermo diviso (tastiera condivisa o due gamepad) · Scuola guida per i principianti
* Voxel art HD generata al volo: niente download pesanti · Italiano / English

## Comandi

| | Giocatore 1 | Giocatore 2 | Gamepad |
|---|---|---|---|
| Accelera | ↑ (o W da solo) | W | A / RT |
| Freno / retromarcia | ↓ (o S) | S | X / LT |
| Sterza | ← → (o A D) | A D | levetta |
| Nitro | Spazio | Q | B / RB |
| Riposiziona | R | E | Y |
| Clacson | H | G | — |
| Telecamera / zoom | C / V | | Back / LB |
| Modalità foto | F | | dal menu di pausa |
| Pausa · audio · prestazioni | P · M · F3 | | Start |

Touch: pad a sinistra per sterzare, pedali a destra, tasti a schermo per nitro, riposiziona e pausa (telefono in orizzontale).

## Requisiti

* Un browser moderno con WebGL (Chrome, Edge, Firefox o Safari aggiornati).
* Consigliata una scheda video dedicata. Sui portatili con due schede video conviene scegliere «Prestazioni elevate» per il
  browser; il gioco controlla la scheda all’avvio e dà i consigli giusti. **F3** mostra le prestazioni.
* Meglio su computer con tastiera o gamepad; gira anche su tablet e telefoni recenti (qualità grafica automatica).
* Connessione internet all’avvio (e per le classifiche online). Niente da installare: record e progressi restano nel browser.

## Riconoscimenti

* **Giacomo Tonezzer** — ideazione, regia, direzione artistica, produzione, collaudo (e record su ogni pista).
* **Sviluppo e programmazione: Claude (Anthropic)**, sotto la direzione di Giacomo Tonezzer.
* **Colonna sonora:** “Toh-NAY-tser Racers”, canzone di Giacomo Tonezzer, realizzata con **Suno**.
* Motore 3D three.js (licenza MIT) · caratteri Bungee e Barlow Condensed (SIL Open Font License) · dati della strada
  Trento–Bondone © OpenStreetMap contributors.

## Contenuto del kit

* `screenshots/` — 1920×1080 dal gioco vero: le 16 della versione 3 (senza interfaccia `*_clean.jpg` e con interfaccia
  `*_hud.jpg`) e 14 nuove della 3.5 (da `17-` a `30-`: i circuiti rinnovati, il Rally a tappe e il parco assistenza,
  l’Eliminazione, le Classifiche, la Coppa Tonezzer, il Demolition Derby, la Trento–Bondone)
* `keyart/` — copertine: itch.io 630×500 e 315×250, capsula 920×430, social 1200×630 (IT ed EN), key art 1920×1080 e 3840×2160
* `logo/` — logo TONEZZER RACERS su trasparente, per fondi chiari e scuri; stemma e marchio Tonezzer’s Arts
* `video/` — trailer 1080p della versione 3 (79 s; `tonezzer-racers-trailer.mp4` con titoli in italiano e sottotitoli
  inglesi, `-en.mp4` in inglese), versione verticale 15 s, loop muto di 7 s (WebM / MP4 / GIF)
* `factsheet_it.md`, `factsheet_en.md`, `itchio.md` (testo pronto per la pagina itch.io), `social.md` (post suggeriti)

Le immagini sono catturate dal gioco vero, senza ritocchi (i nomi in classifica nelle immagini sono di fantasia). Uso libero
per articoli, video e recensioni del gioco.
