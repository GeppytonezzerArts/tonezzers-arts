# Tonezzer Racers — Scheda e kit stampa (versione 3)

**Tonezzer’s Arts** presenta **Tonezzer Racers**, corse off-road in voxel art HD. Gratis, nel browser.

| | |
|---|---|
| **Titolo** | Tonezzer Racers |
| **Versione** | 3 — notte vera, meteo che cambia, terreno vivo, Sfida del giorno (ottobre 2026) |
| **Studio** | Tonezzer’s Arts (titolare: Giacomo Tonezzer) |
| **Genere** | Corse arcade off-road · cronoscalate a tempo |
| **Giocatori** | 1–2 (schermo diviso sullo stesso computer) |
| **Piattaforma** | Browser web (WebGL): PC, Mac, Linux, tablet e telefoni recenti |
| **Prezzo** | Gratis · niente pubblicità, niente registrazione, niente acquisti |
| **Lingue** | Italiano, English |
| **Comandi** | Tastiera, gamepad, touch |
| **Sito / gioca** | https://geppytonezzerarts.github.io/tonezzers-arts/ |
| **Gioco diretto** | https://geppytonezzerarts.github.io/tonezzers-arts/games/tonezzer-racers/ |
| **Trailer** | `video/tonezzer-racers-trailer.mp4` (1080p, 79 s) · `video/tonezzer-racers-trailer-vertical.mp4` (1080×1920, 15 s) |
| **Contatti** | Giacomo Tonezzer (Tonezzer’s Arts) |

## Descrizione breve (≈ 300 caratteri)

Fango, salti e nitro in voxel art HD, di giorno e di notte, con pioggia, neve o nebbia. Tonezzer Racers è il gioco di corse
off-road di Tonezzer’s Arts: 7 mezzi, il Garage Tonezzer, 12 circuiti, 10 cronoscalate, solchi che crescono giro dopo giro e
una Sfida del giorno. Gratis nel browser.

## Descrizione lunga

Quattro mezzi, una pista di fango e zero pietà. **Tonezzer Racers** è l’erede spirituale dei giochi di corse off-road da sala
giochi di una volta, ricostruito voxel per voxel in alta definizione. Si gioca subito, nel browser, gratis: niente da
installare, niente registrazione.

La **versione 3** porta la notte, il meteo e un terreno che si consuma sotto le ruote:

* **Notte vera**: fari che illuminano la strada e luccicano nelle pozzanghere, torri di luci e pozze di luce sulla terra,
  lampioni, catarifrangenti ai bordi della pista, stelle e luna. Al **tramonto** la luce cala durante la gara e si accendono i
  fari.
* **Meteo che cambia**: sereno, **pioggia** (pista bagnata e scivolosa, fango, tuoni e lampi), **neve** (la pista si imbianca)
  o **nebbia** (segui i catarifrangenti), e può cambiare in gara («Comincia a piovere!»). Ora del giorno e meteo si scelgono
  per ogni gara e cronoscalata; nel Gran Premio cambiano a ogni gara.
* **Terreno vivo**: giro dopo giro le ruote scavano solchi nella terra, nel fango, nella sabbia e nella neve; le tracce si
  scuriscono, i solchi profondi si riempiono d’acqua e un po’ ti guidano le ruote. Si può avere anche solo visivo, o spento.
* **Sfida del giorno**: ogni giorno una salita o un circuito, un mezzo uguale per tutti, una regola speciale e il suo cielo;
  conta il tuo tempo migliore, +150 crediti al primo arrivo e la serie dei giorni di fila. In **Record** i tuoi tempi migliori
  di sfide, cronoscalate e giri.

E c’è tutto quello che è arrivato con la **versione 2 — “Garage Tonezzer”**:

* **Sette mezzi**, ognuno con il suo carattere: il Pick-up Classico, la Jeep d’Epoca che si arrampica ovunque, il Buggy
  Zanzara nato per volare, il Rally Saetta, il Trophy Truck Deserto che divora le gobbe, il Monster Bestione che schiaccia i
  sassi (e gli avversari) e la leggendaria **Tonezzer Special**, da sbloccare.
* **Il Garage Tonezzer in 3D**: motore, turbo, trasmissione, gomme, sospensioni, telaio, nitro e blindatura, quattro mescole
  di gomme, vernici, finiture, strisce, cerchi, numeri, adesivi e clacson (sì, anche la paperella). La carriera resta salvata.
* **12 circuiti** dal deserto al canyon al tramonto, dalla palude ai boschi alpini, dalla neve agli stadi illuminati di notte:
  nuovi il **Tonezzer Stadium**, con i fuochi d’artificio all’ultimo giro, e il **Rallycross del Lago**.
* **10 cronoscalate** dalla valle alla vetta contro il cronometro e il tuo fantasma, con medaglie dal bronzo al platino e
  sfide a premi. Quattro sono nuove ed epiche: **Cima delle Nuvole** al tramonto sopra il mare di nuvole, **La Strada della
  Forra** tra gallerie, ponti e castello, **Il Vulcano Tonezzer** attorno al cratere di lava e **Il Passo del Ghiacciaio**
  con il crepaccio da saltare.
* **40 Trofei Tonezzer**, alcuni segreti; la **Modalità foto** con stile cartolina, vintage o bianco e nero; i **danni
  estetici** (ammaccature, vetri incrinati, pezzi che volano: paga Tonezzer).
* La **Scuola guida Tonezzer** per chi comincia, il **Gran Premio Tonezzer’s Arts** contro il Barone per la **Coppa
  Tonezzer**, e il duello a **2 giocatori** a schermo diviso.
* In **italiano e in inglese**, con tastiera, gamepad o touch.

Colonna sonora: la canzone “Toh-NAY-tser Racers” di Giacomo Tonezzer.

## Caratteristiche (elenco)

* Notte vera con fari e luci dinamiche · tramonto che scende in notte durante la gara
* Meteo dinamico: pioggia con tuoni e lampi e pozzanghere, neve che imbianca la pista, nebbia · anche a metà gara
* Terreno vivo: solchi e pozzanghere che crescono giro dopo giro (Sì / Solo visivo / No)
* Sfida del giorno (mezzo e regola uguali per tutti, serie di giorni) e i tuoi record personali
* 7 mezzi con fisica e motore propri, potenziamenti e carrozzeria personalizzabile
* 12 circuiti · Gran Premio da 12 gare · Coppa Tonezzer
* 10 cronoscalate · fantasma del record · medaglie bronzo / argento / oro / platino · 49 sfide
* 40 trofei in cinque famiglie
* Modalità foto (drone libero, stili, luce, sfocatura, salvataggio PNG)
* 2 giocatori a schermo diviso (tastiera condivisa o due gamepad)
* Scuola guida per i principianti, consigli una tantum
* Voxel art HD generata al volo: niente download pesanti
* Italiano / English

## Comandi

| | Giocatore 1 | Giocatore 2 | Gamepad |
|---|---|---|---|
| Accelera | ↑ (o W da solo) | W | A / RT |
| Freno / retromarcia | ↓ (o S) | S | X / LT |
| Sterza | ← → (o A D) | A D | levetta |
| Nitro | Spazio | Q | B / RB |
| Riposiziona | R | E | Y |
| Clacson | H | G | — |
| Telecamera / zoom | C / V | | Back / LB |
| Modalità foto | F | | dal menu di pausa |
| Pausa · audio | P · M | | Start |

Touch: pad a sinistra per sterzare, pedali a destra, tasti a schermo per nitro, riposiziona e pausa (telefono in orizzontale).

## Requisiti

* Un browser moderno con WebGL (Chrome, Edge, Firefox o Safari aggiornati).
* Meglio su computer con tastiera o gamepad; gira anche su tablet e telefoni recenti (qualità grafica automatica).
* Connessione internet all’avvio. Niente da installare: record e progressi restano nel browser.

## Riconoscimenti

* **Giacomo Tonezzer** — ideazione, regia, direzione artistica, produzione, collaudo (e record su ogni pista).
* **Sviluppo e programmazione: Claude (Anthropic)**, sotto la direzione di Giacomo Tonezzer.
* **Colonna sonora:** “Toh-NAY-tser Racers”, canzone di Giacomo Tonezzer, realizzata con **Suno**.
* Motore 3D three.js (licenza MIT) · caratteri Bungee e Barlow Condensed (SIL Open Font License).

## Contenuto del kit

* `screenshots/` — 16 immagini 1920×1080 (nuove della v3: notte, pioggia, neve, terreno vivo, nebbia, il Vulcano di notte) (versione senza interfaccia `*_clean.jpg` e con interfaccia `*_hud.jpg`)
* `keyart/` — copertine: itch.io 630×500 e 315×250, capsula 920×430, social 1200×630 (IT ed EN), key art 1920×1080
* `logo/` — logo TONEZZER RACERS su trasparente, per fondi chiari e scuri; stemma Tonezzer’s Arts
* `video/` — trailer 1080p della versione 3 (79 s; `tonezzer-racers-trailer.mp4` con titoli in italiano e sottotitoli inglesi, `-en.mp4` in inglese), versione verticale 15 s, loop muto di 7 s (WebM / MP4 / GIF)
* `factsheet_it.md`, `factsheet_en.md`, `itchio.md` (testo pronto per la pagina itch.io), `social.md` (post suggeriti)

Le immagini sono catturate dal gioco vero, senza ritocchi. Uso libero per articoli, video e recensioni del gioco.
