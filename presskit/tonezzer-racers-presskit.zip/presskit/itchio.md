# itch.io page — ready to paste

Settings suggested for the itch.io project page:

* **Title:** Tonezzer Racers
* **Short description / tagline:** Mud, jumps and nitro in HD voxel art — 12 circuits full of ups and downs, rallies, elimination, a derby and online leaderboards. Free in your browser
* **Classification:** Games · **Kind of project:** HTML (or an external link to the website)
* **Genre:** Racing · **Tags:** racing, off-road, voxel, arcade, 3d, local-multiplayer, split-screen, hill-climb, rally, leaderboards, weather, night, retro, free
* **Cover image:** `keyart/cover-630x500.png` (the 315×250 version for small slots) · **Screenshots:** the `screenshots/*_hud.jpg`
  and `*_clean.jpg` files · **Trailer:** the YouTube upload of `video/tonezzer-racers-trailer.mp4`
* **Embed options (HTML upload):** 1280×720, “Mobile friendly”, “Fullscreen button”, landscape. Or point the page to
  https://geppytonezzerarts.github.io/tonezzers-arts/games/tonezzer-racers/
* **Languages:** English, Italian · **Inputs:** Keyboard, Gamepad, Touchscreen · **Multiplayer:** Local multiplayer, 2 players
* **Pricing:** No payments (or “$0 or donate”)

---

## Page body (English)

**Mud, jumps and nitro — in HD voxel art.**

Seven vehicles, one mud track and zero mercy. **Tonezzer Racers** is the spiritual heir to the off-road arcade racers of
yesteryear, rebuilt voxel by voxel in high definition by **Tonezzer’s Arts**, the world-famous production house of Giacomo
Tonezzer. *The world’s greatest games, since forever.*

### New in version 3.5 — “Saliscendi” (Ups and downs)

* ⛰️ **12 reworked circuits**: more climbs and dives, crests you really fly off, five brand-new layouts — the Wolf Hairpins and
  the Wolf Leap, Le Forcelle and the 60–70 m Ski Jump of Lakeside Rallycross, the Lava Circle of Fire Canyon, the Neon Tower
  of Tonezzer Ring, the three 22 m arches of Three Arches
* 🏁 **Stage Rally**: three rallies of hill climbs against five rivals, damage that carries over and the **service park**
  between stages — the Grand Rally ends on the legendary **Trento–Bondone**
* ❌ **Elimination**: 4 to 6 cars, the last one is out at the end of every lap — “YOU’RE LAST!”
* 🌍 **Online leaderboards**: hill climbs, best laps, the daily challenge and the rallies against everyone (a leaderboard
  name, no account)
* 🏆 **The Tonezzer Cup ceremony**: the Grand Prix ends on the podium, with fanfare and fireworks; leave the Garage and resume
  later
* 💥 **Demolition Derby**: 6 to 8 cars in three arenas, the last one standing wins
* ⚡ Smoother hill climbs, a graphics-card check with tips and performance stats on F3

### Version 3

* 🌙 **A real night**: headlights lighting the road and glinting in the puddles, floodlight towers, lamps, reflective markers,
  stars and moon — and sunsets that fade into night during the race
* 🌧️ **Changing weather**: rain with thunder, lightning and a slippery track, snow that turns it white, fog — even mid-race.
  Pick the time of day and the weather for every race and climb
* 🛞 **Living terrain**: ruts that grow lap after lap in dirt, mud, sand and snow, filling with water in the rain
* 📅 **Daily challenge**: a new climb or circuit every day, the same vehicle and rule for everyone, your streak — and
  **Records** with all your personal bests

### Version 2 — “Garage Tonezzer”

* 🚙 **7 vehicles**: Classic Pick-up, Vintage Jeep, Buggy Zanzara, Rally Saetta, Desert Trophy Truck, Monster Bestione — and
  the legendary **Tonezzer Special** to unlock
* 🔧 **The Tonezzer Garage** in 3D: engine, turbo, tyres, suspension, nitro, armour… plus paints, stripes, rims, decals and
  horns (yes, a rubber duck)
* 🏁 **12 circuits** — deserts, canyons at sunset, swamps, alpine forests, snow and floodlit night stadiums (fireworks
  included)
* ⛰️ **11 hill climbs** against the clock and your own ghost, bronze to platinum medals and over 60 challenges — new: Cima delle
  Nuvole above a sea of clouds, the Gorge Road and its castle, Tonezzer’s Volcano, the Glacier Pass and its crevasse
* 🏆 **55 Tonezzer Trophies** (some secret) · 📸 **Photo mode** with postcard style · 💥 cosmetic damage
* 👥 **2 players** on the same screen · 🎓 the Tonezzer Driving School for beginners
* 🇮🇹 🇬🇧 Italian and English

### Controls

| | Player 1 | Player 2 | Gamepad |
|---|---|---|---|
| Drive | arrows (or WASD alone) | WASD | stick, A / RT, X / LT |
| Nitro | Space | Q | B / RB |
| Reset | R | E | Y |
| Horn | H | G | |

C camera · V zoom · F photo mode · P pause · M audio. On phones and tablets: touch controls, landscape.

### Requirements

A modern browser with WebGL; a dedicated graphics card is recommended (on laptops with two, pick “High performance” for the browser). Best on a computer with keyboard or gamepad; runs on recent phones and tablets too. Records and
progress are saved in your browser.

### Credits

Concept and direction: **Giacomo Tonezzer** · Development: **Claude (Anthropic)**, under the direction of Giacomo Tonezzer ·
Soundtrack: “Toh-NAY-tser Racers” by Giacomo Tonezzer, made with **Suno** · three.js (MIT) · Bungee & Barlow Condensed (OFL)

*No pick-ups were harmed in the making of this production. Except the Baron’s.*

---

## Corpo della pagina (italiano)

**Fango, salti e nitro — in voxel art HD.**

Sette mezzi, una pista di fango e zero pietà. **Tonezzer Racers** è l’erede spirituale dei giochi di corse off-road da sala
giochi di una volta, ricostruito voxel per voxel in alta definizione da **Tonezzer’s Arts**, la celeberrima casa di produzione
di Giacomo Tonezzer. *Da sempre, i migliori giochi del mondo.*

### Novità della versione 3.5 — “Saliscendi”

* ⛰️ **12 circuiti rinnovati**: più salite e picchiate, dossi da cui si vola davvero, cinque tracciati nuovi — i Tornanti e il
  Salto del Lupo, Le Forcelle e il Trampolino da 60–70 m del Rallycross del Lago, il Girone di Lava del Canyon del Fuoco, la
  Torre dei Neon del Tonezzer Ring, i tre archi alti 22 m di Tre Archi
* 🏁 **Rally a tappe**: tre rally di cronoscalate contro cinque rivali, danni che restano e il **parco assistenza** tra le prove —
  il Gran Rally finisce sulla leggendaria **Trento–Bondone**
* ❌ **Eliminazione**: da 4 a 6 auto, l’ultimo è fuori alla fine di ogni giro — «SEI ULTIMO!»
* 🌍 **Classifiche online**: cronoscalate, giri veloci, Sfida del giorno e rally contro tutti (un nome in classifica, nessun
  account)
* 🏆 **La premiazione della Coppa Tonezzer**: il Gran Premio finisce sul podio, con fanfara e fuochi d’artificio; esci dal
  Garage e riprendi quando vuoi
* 💥 **Demolition Derby**: da 6 a 8 auto in tre arene, l’ultimo in piedi vince
* ⚡ Cronoscalate più fluide, controllo della scheda video con consigli e statistiche delle prestazioni con F3

### Versione 3

* 🌙 **Notte vera**: fari che illuminano la strada e luccicano nelle pozzanghere, torri di luci, lampioni, catarifrangenti,
  stelle e luna — e tramonti che scendono in notte durante la gara
* 🌧️ **Meteo che cambia**: pioggia con tuoni, lampi e pista scivolosa, neve che la imbianca, nebbia — anche a metà gara.
  Scegli ora del giorno e meteo per ogni gara e cronoscalata
* 🛞 **Terreno vivo**: solchi che crescono giro dopo giro nella terra, nel fango, nella sabbia e nella neve, e con la pioggia si
  riempiono d’acqua
* 📅 **Sfida del giorno**: ogni giorno una salita o un circuito, lo stesso mezzo e la stessa regola per tutti, la tua serie di
  giorni — e **Record** con tutti i tuoi tempi migliori

### Versione 2 — “Garage Tonezzer”

* 🚙 **7 mezzi**: Pick-up Classico, Jeep d’Epoca, Buggy Zanzara, Rally Saetta, Trophy Truck Deserto, Monster Bestione — e la
  leggendaria **Tonezzer Special** da sbloccare
* 🔧 **Il Garage Tonezzer** in 3D: motore, turbo, gomme, sospensioni, nitro, blindatura… e vernici, strisce, cerchi, adesivi e
  clacson (sì, anche la paperella)
* 🏁 **12 circuiti** — deserti, canyon al tramonto, paludi, boschi alpini, neve e stadi illuminati di notte (fuochi d’artificio
  compresi)
* ⛰️ **11 cronoscalate** contro il cronometro e il tuo fantasma, medaglie dal bronzo al platino e oltre 60 sfide — nuove: Cima delle
  Nuvole sopra il mare di nuvole, La Strada della Forra e il suo castello, Il Vulcano Tonezzer, Il Passo del Ghiacciaio e il
  suo crepaccio
* 🏆 **55 Trofei Tonezzer** (qualcuno segreto) · 📸 **Modalità foto** con lo stile cartolina · 💥 danni estetici
* 👥 **2 giocatori** sullo stesso schermo · 🎓 la Scuola guida Tonezzer per chi comincia
* 🇮🇹 🇬🇧 Italiano e inglese

### Comandi

| | Giocatore 1 | Giocatore 2 | Gamepad |
|---|---|---|---|
| Guida | frecce (o WASD da solo) | WASD | levetta, A / RT, X / LT |
| Nitro | Spazio | Q | B / RB |
| Riposiziona | R | E | Y |
| Clacson | H | G | |

C telecamera · V zoom · F modalità foto · P pausa · M audio. Su telefono e tablet: comandi touch, in orizzontale.

### Requisiti

Un browser moderno con WebGL; consigliata una scheda video dedicata (sui portatili con due, scegli «Prestazioni elevate» per il browser). Meglio su computer con tastiera o gamepad; gira anche su telefoni e tablet recenti. Record e
progressi restano salvati nel browser.

### Riconoscimenti

Ideazione e regia: **Giacomo Tonezzer** · Sviluppo: **Claude (Anthropic)**, sotto la direzione di Giacomo Tonezzer · Colonna
sonora: “Toh-NAY-tser Racers” di Giacomo Tonezzer, realizzata con **Suno** · three.js (MIT) · Bungee e Barlow Condensed (OFL)

*Nessun pick-up è stato maltrattato durante la produzione. Tranne quelli del Barone.*
