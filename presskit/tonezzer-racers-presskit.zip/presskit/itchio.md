# itch.io page — ready to paste

Settings suggested for the itch.io project page:

* **Title:** Tonezzer Racers
* **Short description / tagline:** Mud, jumps and nitro in HD voxel art — free in your browser
* **Classification:** Games · **Kind of project:** HTML (or an external link to the website)
* **Genre:** Racing · **Tags:** racing, off-road, voxel, arcade, 3d, local-multiplayer, split-screen, hill-climb, retro, free
* **Cover image:** `keyart/cover-630x500.png` (the 315×250 version for small slots) · **Screenshots:** the `screenshots/*_hud.jpg`
  and `*_clean.jpg` files · **Trailer:** the YouTube upload of `video/tonezzer-racers-trailer.mp4`
* **Embed options (HTML upload):** 1280×720, “Mobile friendly”, “Fullscreen button”, landscape. Or point the page to
  https://geppytonezzerarts.github.io/tonezzers-arts/games/tonezzer-racers/
* **Languages:** English, Italian · **Inputs:** Keyboard, Gamepad, Touchscreen · **Multiplayer:** Local multiplayer, 2 players
* **Pricing:** No payments (or “$0 or donate”)

---

## Page body (English)

**Mud, jumps and nitro — in HD voxel art.**

Four trucks, one mud track and zero mercy. **Tonezzer Racers** is the spiritual heir to the off-road arcade racers of
yesteryear, rebuilt voxel by voxel in high definition by **Tonezzer’s Arts**, the world-famous production house of Giacomo
Tonezzer. *The world’s greatest games, since forever.*

### New in version 2 — “Garage Tonezzer”

* 🚙 **7 vehicles**: Classic Pick-up, Vintage Jeep, Buggy Zanzara, Rally Saetta, Desert Trophy Truck, Monster Bestione — and
  the legendary **Tonezzer Special** to unlock
* 🔧 **The Tonezzer Garage** in 3D: engine, turbo, tyres, suspension, nitro, armour… plus paints, stripes, rims, decals and
  horns (yes, a rubber duck)
* 🏁 **12 circuits** — deserts, canyons at sunset, swamps, alpine forests, snow and floodlit night stadiums (fireworks
  included)
* ⛰️ **10 hill climbs** against the clock and your own ghost, bronze to platinum medals and 49 challenges — new: Cima delle
  Nuvole above a sea of clouds, the Gorge Road and its castle, Tonezzer’s Volcano, the Glacier Pass and its crevasse
* 🏆 **40 Tonezzer Trophies** (some secret) · 📸 **Photo mode** with postcard style · 💥 cosmetic damage
* 👥 **2 players** on the same screen · 🎓 the Tonezzer Driving School for beginners
* 🇮🇹 🇬🇧 Italian and English

### Controls

| | Player 1 | Player 2 | Gamepad |
|---|---|---|---|
| Drive | arrows (or WASD alone) | WASD | stick, A / RT, X / LT |
| Nitro | Space | Q | B / RB |
| Reset | R | E | Y |
| Horn | H | G | |

C camera · V zoom · F photo mode · P pause · M audio. On phones and tablets: touch controls, landscape.

### Requirements

A modern browser with WebGL. Best on a computer with keyboard or gamepad; runs on recent phones and tablets too. Records and
progress are saved in your browser.

### Credits

Concept and direction: **Giacomo Tonezzer** · Development: **Claude (Anthropic)**, under the direction of Giacomo Tonezzer ·
Soundtrack: “Toh-NAY-tser Racers” by Giacomo Tonezzer, made with **Suno** · three.js (MIT) · Bungee & Barlow Condensed (OFL)

*No pick-ups were harmed in the making of this production. Except the Baron’s.*

---

## Corpo della pagina (italiano)

**Fango, salti e nitro — in voxel art HD.**

Quattro mezzi, una pista di fango e zero pietà. **Tonezzer Racers** è l’erede spirituale dei giochi di corse off-road da sala
giochi di una volta, ricostruito voxel per voxel in alta definizione da **Tonezzer’s Arts**, la celeberrima casa di produzione
di Giacomo Tonezzer. *Da sempre, i migliori giochi del mondo.*

### Novità della versione 2 — “Garage Tonezzer”

* 🚙 **7 mezzi**: Pick-up Classico, Jeep d’Epoca, Buggy Zanzara, Rally Saetta, Trophy Truck Deserto, Monster Bestione — e la
  leggendaria **Tonezzer Special** da sbloccare
* 🔧 **Il Garage Tonezzer** in 3D: motore, turbo, gomme, sospensioni, nitro, blindatura… e vernici, strisce, cerchi, adesivi e
  clacson (sì, anche la paperella)
* 🏁 **12 circuiti** — deserti, canyon al tramonto, paludi, boschi alpini, neve e stadi illuminati di notte (fuochi d’artificio
  compresi)
* ⛰️ **10 cronoscalate** contro il cronometro e il tuo fantasma, medaglie dal bronzo al platino e 49 sfide — nuove: Cima delle
  Nuvole sopra il mare di nuvole, La Strada della Forra e il suo castello, Il Vulcano Tonezzer, Il Passo del Ghiacciaio e il
  suo crepaccio
* 🏆 **40 Trofei Tonezzer** (qualcuno segreto) · 📸 **Modalità foto** con lo stile cartolina · 💥 danni estetici
* 👥 **2 giocatori** sullo stesso schermo · 🎓 la Scuola guida Tonezzer per chi comincia
* 🇮🇹 🇬🇧 Italiano e inglese

### Comandi

| | Giocatore 1 | Giocatore 2 | Gamepad |
|---|---|---|---|
| Guida | frecce (o WASD da solo) | WASD | levetta, A / RT, X / LT |
| Nitro | Spazio | Q | B / RB |
| Riposiziona | R | E | Y |
| Clacson | H | G | |

C telecamera · V zoom · F modalità foto · P pausa · M audio. Su telefono e tablet: comandi touch, in orizzontale.

### Requisiti

Un browser moderno con WebGL. Meglio su computer con tastiera o gamepad; gira anche su telefoni e tablet recenti. Record e
progressi restano salvati nel browser.

### Riconoscimenti

Ideazione e regia: **Giacomo Tonezzer** · Sviluppo: **Claude (Anthropic)**, sotto la direzione di Giacomo Tonezzer · Colonna
sonora: “Toh-NAY-tser Racers” di Giacomo Tonezzer, realizzata con **Suno** · three.js (MIT) · Bungee e Barlow Condensed (OFL)

*Nessun pick-up è stato maltrattato durante la produzione. Tranne quelli del Barone.*
